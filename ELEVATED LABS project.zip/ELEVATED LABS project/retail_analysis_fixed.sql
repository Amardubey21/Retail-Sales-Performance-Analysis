DROP TABLE IF EXISTS superstore_sales;
CREATE TABLE superstore_sales (
    row_id INT,
    order_id VARCHAR(20),
    order_date DATE,
    ship_date DATE,
    ship_mode VARCHAR(50),
    customer_id VARCHAR(20),
    customer_name VARCHAR(100),
    segment VARCHAR(50),
    country VARCHAR(50),
    city VARCHAR(50),
    state VARCHAR(50),
    postal_code VARCHAR(20),
    region VARCHAR(50),
    product_id VARCHAR(20),
    category VARCHAR(50),
    sub_category VARCHAR(50),
    product_name VARCHAR(200),
    sales NUMERIC,
    quantity INT,
    discount NUMERIC,
    profit NUMERIC
);
SELECT *
FROM superstore_sales
LIMIT 5;

SELECT 
    column_name, 
    data_type
FROM information_schema.columns
WHERE table_name = 'superstore_sales';

-- 2️⃣ PROFITABILITY BY CATEGORY AND SUB-CATEGORY
SELECT 
    category,
    "sub-category",
    ROUND(SUM(sales)::NUMERIC, 2) AS total_sales,
    ROUND(SUM(profit)::NUMERIC, 2) AS total_profit,
    ROUND(SUM(profit)::NUMERIC / NULLIF(SUM(sales)::NUMERIC, 0) * 100, 2) AS profit_margin
FROM superstore_sales
GROUP BY category, "sub-category"
ORDER BY profit_margin DESC;

-- 3️⃣ REGIONAL SALES & PROFIT PERFORMANCE
SELECT 
    region,
    ROUND(SUM(sales)::NUMERIC, 2) AS total_sales,
    ROUND(SUM(profit)::NUMERIC, 2) AS total_profit,
    ROUND(SUM(profit)::NUMERIC / NULLIF(SUM(sales)::NUMERIC, 0) * 100, 2) AS profit_margin
FROM superstore_sales
GROUP BY region
ORDER BY total_profit DESC;

-- 4️⃣ TOP 10 MOST PROFITABLE PRODUCTS
SELECT 
    product_name,
    category,
    ROUND(SUM(sales)::NUMERIC, 2) AS total_sales,
    ROUND(SUM(profit)::NUMERIC, 2) AS total_profit
FROM superstore_sales
GROUP BY product_name, category
ORDER BY total_profit DESC
LIMIT 10;

-- 5️⃣ PRODUCTS CAUSING HIGHEST LOSS
SELECT 
    product_name,
    category,
    ROUND(SUM(sales)::NUMERIC, 2) AS total_sales,
    ROUND(SUM(profit)::NUMERIC, 2) AS total_profit
FROM superstore_sales
GROUP BY product_name, category
HAVING SUM(profit) < 0
ORDER BY total_profit ASC
LIMIT 10;




